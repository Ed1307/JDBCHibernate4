CREATE PROCEDURE phone_and_adress()
  begin
select phone, adress
from name_and_number
join marital_and_date_and_adress
on name_and_number.employee_id = marital_and_date_and_adress.employee_id;
end;
